var alert = 'Elektron-poçt ünvanını düzgün daxil edin! **@** tələb olunur.';
var successMsg = 'Müraciətiniz təsdiqləndi.';
var message = document.createElement('p');
message.innerHTML = successMsg;

const validMail = /^\S+@\S+\.\S+$/;
document.getElementById('btn-cont').onclick = function() {
   var mail = document.getElementById("email").value;
      
   if (!validMail.test(mail)) {
     var infoForm = document.getElementById("info-form");
     message.innerHTML = alert;
     infoForm.appendChild(message);
     message.style.color = "#891111";
     message.style.fontSize = "110%";
     message.style.fontFamily = "Arial,sans-serif";
     message.style.marginLeft = "3%";
   } 
   else {
     var infoForm = document.getElementById("info-form");
     infoForm.appendChild(message);
     message.innerHTML = successMsg;
     message.style.color = "#246324";
     message.style.marginLeft = "3%";
     message.style.fontFamily = "Arial,sans-serif";
     message.style.fontSize = "110%";
   }
}
